import postgres from 'postgres';


// Set your PostgreSQL credentials
const username = 'postgres';
const password = 'kumuda'; // Replace with your actual password
const host = 'localhost';
const port = '5432';
const databaseName = 'Postgres';

// Create the DATABASE_URL using the provided credentials
export const DATABASE_URL = `postgres://${postgres}:${kumuda}@${localhost}:${5432}/${Postgres}`;

// Use the DATABASE_URL in the postgres configuration
export const sql = postgres(DATABASE_URL, { ssl: 'require' });
